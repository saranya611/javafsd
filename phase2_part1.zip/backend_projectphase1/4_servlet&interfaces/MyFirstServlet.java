import java.io.*;
import javax.servlet.*;

// Class
public class MyFirstServlet implements Servlet {

	ServletConfig config = null;

	// Method 1
	public void init(ServletConfig config)
	{
		// this keyword refers to current instance itself
		this.config = config;

		System.out.println("servlet is initialized:::"
						+ config);
	}

	// Method 2
	public void service(ServletRequest request,
						ServletResponse response)
		throws IOException, ServletException
	{

		response.setContentType("text/html");

		// Response interface of servlet is use
		PrintWriter out = response.getWriter();

		out.print("<html><body>");

<h1><b>Welcome to GFG PORTAL</b></h1>");
out.print("
<h2><b> Example of Servlet Interface <b></h2>");
out.print("</body></html>");
	}

	// Method 3
	public void destroy()
	{
		System.out.println("servlet is destroyed now");
	}

	// Method 4
	public ServletConfig getServletConfig()
	{
		return config;
	}

	// Method 5
	public String getServletInfo()
	{
		return "copyright 2007-2011";
	}
}

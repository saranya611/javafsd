import java.util.Scanner;

public class primitive {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the string : ");
        // getting input from user
        String str = sc.nextLine();
        System.out.println("the input string is: " + str);
        // converting string to double
        double a = Double.parseDouble(str);
        System.out.println("conversion of string to double: " + a);
        // converting string to integer
        int b = Integer.parseInt(str);
        System.out.println("conversion of string to integer: " + b);
        // converting string to float
        float c = Float.parseFloat(str);
        System.out.println("conversion of string to float: " + c);
        // converting string to long
        long d = Long.parseLong(str);
        System.out.println("conversion of string to Long: " + d);
        // converting string to boolean
        boolean e = Boolean.parseBoolean(str);
        System.out.println("conversion of string to Boolean: " + e);
        // converting string to character
        System.out.println("conversion of string to character: ");
        char f;
        for (int i = 0; i < str.length(); i++) {
            f = str.charAt(i);
            System.out.println("char in " + i + "th position is " + f);
        }
        // converting string to short
        short g = Short.parseShort(str);
        System.out.println("conversion of string to short: " + g);
        // conversion of string to byte
        byte h = Byte.parseByte(str);
        System.out.println("conversion of string to byte: " + h);
    }

}